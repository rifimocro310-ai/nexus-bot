const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../config');

const XP_PATH = path.join(__dirname, '../data/xp.json');
const spamTracker = new Map();
const xpCooldowns = new Map();

function loadXP() {
    if (!fs.existsSync(XP_PATH)) return {};
    return JSON.parse(fs.readFileSync(XP_PATH, 'utf8'));
}
function saveXP(data) {
    fs.writeFileSync(XP_PATH, JSON.stringify(data, null, 2));
}
function xpForLevel(level) {
    return 100 * level * level;
}

const LINK_REGEX = /(https?:\/\/|www\.|discord\.gg\/)[^\s]+/gi;
const PREFIX = config.PREFIX || '!';

module.exports = {
    name: 'messageCreate',
    async execute(message, client) {
        if (!message.guild || message.author.bot) return;

        const protection = config.PROTECTION;

        // ======== Anti-Link ========
        if (protection.ANTI_LINK.ENABLED) {
            const hasLink = LINK_REGEX.test(message.content);
            LINK_REGEX.lastIndex = 0;

            if (hasLink) {
                const isExempt = protection.ANTI_LINK.WHITELIST_ROLES.some(r => message.member.roles.cache.has(r))
                    || message.member.permissions.has('ManageMessages');
                const isWhitelisted = protection.ANTI_LINK.WHITELIST_DOMAINS.some(d => message.content.includes(d));

                if (!isExempt && !isWhitelisted) {
                    await message.delete().catch(() => {});
                    const warn = await message.channel.send(`⚠️ <@${message.author.id}> ممنوع إرسال الروابط!`);
                    setTimeout(() => warn.delete().catch(() => {}), 5000);
                    return;
                }
            }
        }

        // ======== Anti-Spam ========
        if (protection.ANTI_SPAM.ENABLED && !message.member.permissions.has('ManageMessages')) {
            const key = `${message.guild.id}_${message.author.id}`;
            const now = Date.now();
            const userData = spamTracker.get(key) || { messages: [], warned: false };

            userData.messages = userData.messages.filter(t => now - t < protection.ANTI_SPAM.TIME_WINDOW_MS);
            userData.messages.push(now);
            spamTracker.set(key, userData);

            if (userData.messages.length >= protection.ANTI_SPAM.MAX_MESSAGES) {
                await message.delete().catch(() => {});
                if (!userData.warned) {
                    userData.warned = true;
                    const warn = await message.channel.send(`⚠️ <@${message.author.id}> أنت تُرسل رسائل بسرعة كبيرة!`);
                    setTimeout(() => {
                        warn.delete().catch(() => {});
                        userData.warned = false;
                        userData.messages = [];
                    }, 5000);
                }
                return;
            }
        }

        // ======== نظام XP ========
        if (!config.XP.EXCLUDED_CHANNELS.includes(message.channel.id)) {
            const now = Date.now();
            const cooldownKey = `${message.guild.id}_${message.author.id}`;
            const lastXP = xpCooldowns.get(cooldownKey) || 0;

            if (now - lastXP > config.XP.COOLDOWN_SECONDS * 1000) {
                xpCooldowns.set(cooldownKey, now);
                const xpData = loadXP();
                const uid = message.author.id;
                if (!xpData[uid]) xpData[uid] = { xp: 0, level: 0 };

                const earned = Math.floor(Math.random() * (config.XP.MAX_PER_MESSAGE - config.XP.MIN_PER_MESSAGE + 1)) + config.XP.MIN_PER_MESSAGE;
                xpData[uid].xp += earned;

                const needed = xpForLevel(xpData[uid].level + 1);
                if (xpData[uid].xp >= needed) {
                    xpData[uid].level++;
                    const levelUpChannel = message.guild.channels.cache.get(config.CHANNELS.LEVEL_UP);
                    const channel = levelUpChannel || message.channel;
                    const embed = new EmbedBuilder()
                        .setColor('#FFD700')
                        .setTitle('⬆️ ترقية مستوى!')
                        .setDescription(`🎉 تهانينا <@${message.author.id}>!\nوصلت إلى المستوى **${xpData[uid].level}**!`)
                        .setThumbnail(message.author.displayAvatarURL())
                        .setTimestamp();
                    channel.send({ embeds: [embed] }).catch(() => {});
                }
                saveXP(xpData);
            }
        }

        // ======== معالجة الأوامر بـ Prefix ========
        if (!message.content.startsWith(PREFIX)) return;

        const args = message.content.slice(PREFIX.length).trim().split(/\s+/);
        const commandName = args.shift().toLowerCase();

        // البحث عن الأمر بالاسم أو الاختصارات
        const command = client.commands.get(commandName) ||
            client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));

        if (!command) return;

        try {
            await command.execute(message, args, client);
        } catch (err) {
            console.error(`خطأ في الأمر ${commandName}:`, err);
            message.reply('❌ حدث خطأ أثناء تنفيذ الأمر.').catch(() => {});
        }
    }
};
