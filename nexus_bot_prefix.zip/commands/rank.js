const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const XP_PATH = path.join(__dirname, '../data/xp.json');

function loadXP() {
    if (!fs.existsSync(XP_PATH)) return {};
    return JSON.parse(fs.readFileSync(XP_PATH, 'utf8'));
}
function xpForLevel(level) { return 100 * level * level; }

module.exports = {
    name: 'rank',
    description: 'عرض مستواك | !rank [@عضو]',
    async execute(message, args, client) {
        const target = message.mentions.members.first() || message.member;
        const xpData = loadXP();
        const uid = target.id;
        const user = xpData[uid] || { xp: 0, level: 0 };

        const embed = new EmbedBuilder()
            .setColor('#FFD700')
            .setTitle(`📊 مستوى ${target.displayName}`)
            .setThumbnail(target.user.displayAvatarURL())
            .addFields(
                { name: '⭐ المستوى', value: `${user.level}`, inline: true },
                { name: '✨ XP', value: `${user.xp}`, inline: true },
                { name: '📈 للمستوى القادم', value: `${xpForLevel(user.level + 1) - user.xp} XP`, inline: true }
            )
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    }
};
