const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'kick',
    description: 'طرد عضو | !kick @عضو [سبب]',
    async execute(message, args, client) {
        if (!message.member.permissions.has('KickMembers'))
            return message.reply('❌ ليس لديك صلاحية الطرد.');

        const target = message.mentions.members.first();
        if (!target) return message.reply('❌ اذكر العضو: `!kick @عضو [سبب]`');
        if (!target.kickable) return message.reply('❌ لا يمكن طرد هذا العضو.');

        const reason = args.slice(1).join(' ') || 'لم يُحدد سبب';

        try {
            await target.send(`👢 تم طردك من **${message.guild.name}**\n📝 السبب: ${reason}`).catch(() => {});
            await target.kick(reason);

            const embed = new EmbedBuilder()
                .setColor('#FF8800')
                .setTitle('👢 تم الطرد')
                .addFields(
                    { name: '👤 العضو', value: `${target.user.tag}`, inline: true },
                    { name: '🛡️ بواسطة', value: `${message.author.tag}`, inline: true },
                    { name: '📝 السبب', value: reason }
                )
                .setTimestamp();

            await message.channel.send({ embeds: [embed] });

            const logsChannel = message.guild.channels.cache.get(process.env.LOGS_CHANNEL_ID);
            if (logsChannel) await logsChannel.send({ embeds: [embed] });
        } catch (err) {
            message.reply(`❌ فشل الطرد: ${err.message}`);
        }
    }
};
