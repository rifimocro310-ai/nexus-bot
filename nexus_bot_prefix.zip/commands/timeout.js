const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'timeout',
    description: 'كتم عضو | !timeout @عضو [دقائق] [سبب]',
    async execute(message, args, client) {
        if (!message.member.permissions.has('ModerateMembers'))
            return message.reply('❌ ليس لديك صلاحية الكتم.');

        const target = message.mentions.members.first();
        if (!target) return message.reply('❌ اذكر العضو: `!timeout @عضو [دقائق] [سبب]`');

        const minutes = parseInt(args[1]) || 10;
        const reason = args.slice(2).join(' ') || 'لم يُحدد سبب';
        const ms = minutes * 60 * 1000;

        try {
            await target.timeout(ms, reason);

            const embed = new EmbedBuilder()
                .setColor('#FFAA00')
                .setTitle('🔇 تم الكتم')
                .addFields(
                    { name: '👤 العضو', value: `${target.user.tag}`, inline: true },
                    { name: '⏱️ المدة', value: `${minutes} دقيقة`, inline: true },
                    { name: '📝 السبب', value: reason }
                )
                .setTimestamp();

            await message.channel.send({ embeds: [embed] });
        } catch (err) {
            message.reply(`❌ فشل الكتم: ${err.message}`);
        }
    }
};
