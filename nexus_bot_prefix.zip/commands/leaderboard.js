const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const XP_PATH = path.join(__dirname, '../data/xp.json');

function loadXP() {
    if (!fs.existsSync(XP_PATH)) return {};
    return JSON.parse(fs.readFileSync(XP_PATH, 'utf8'));
}

module.exports = {
    name: 'leaderboard',
    aliases: ['lb', 'top'],
    description: 'لوحة المتصدرين | !leaderboard',
    async execute(message, args, client) {
        const xpData = loadXP();
        const sorted = Object.entries(xpData)
            .sort((a, b) => b[1].xp - a[1].xp)
            .slice(0, 10);

        if (!sorted.length) return message.reply('📊 لا يوجد بيانات بعد.');

        const medals = ['🥇', '🥈', '🥉'];
        let description = '';
        for (let i = 0; i < sorted.length; i++) {
            const [id, data] = sorted[i];
            const medal = medals[i] || `**${i + 1}.**`;
            description += `${medal} <@${id}> — المستوى **${data.level}** | **${data.xp}** XP\n`;
        }

        const embed = new EmbedBuilder()
            .setColor('#FFD700')
            .setTitle('🏆 لوحة المتصدرين')
            .setDescription(description)
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    }
};
