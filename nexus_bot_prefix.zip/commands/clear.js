module.exports = {
    name: 'clear',
    description: 'حذف رسائل | !clear [عدد]',
    async execute(message, args, client) {
        if (!message.member.permissions.has('ManageMessages'))
            return message.reply('❌ ليس لديك صلاحية حذف الرسائل.');

        const amount = parseInt(args[0]);
        if (!amount || amount < 1 || amount > 100)
            return message.reply('❌ اذكر عدداً بين 1 و100: `!clear 10`');

        try {
            await message.delete();
            const deleted = await message.channel.bulkDelete(amount, true);
            const msg = await message.channel.send(`✅ تم حذف **${deleted.size}** رسالة.`);
            setTimeout(() => msg.delete().catch(() => {}), 3000);
        } catch (err) {
            message.channel.send(`❌ فشل الحذف: ${err.message}`);
        }
    }
};
