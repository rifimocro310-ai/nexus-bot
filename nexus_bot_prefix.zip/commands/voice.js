const { joinVoiceChannel, VoiceConnectionStatus, entersState, getVoiceConnection } = require('@discordjs/voice');

module.exports = {
    name: 'voice',
    aliases: ['vc'],
    description: 'التحكم في الصوت | !voice join / !voice leave',
    async execute(message, args, client) {
        const sub = args[0]?.toLowerCase();

        if (sub === 'join') {
            const voiceChannel = message.member.voice.channel;
            if (!voiceChannel)
                return message.reply('❌ يجب أن تكون في قناة صوتية أولاً.');

            try {
                const connection = joinVoiceChannel({
                    channelId: voiceChannel.id,
                    guildId: message.guild.id,
                    adapterCreator: message.guild.voiceAdapterCreator,
                    selfDeaf: true,
                    selfMute: true,
                });
                await entersState(connection, VoiceConnectionStatus.Ready, 30_000);
                message.reply(`✅ تم الدخول إلى **${voiceChannel.name}**`);
            } catch {
                message.reply('❌ تعذر الدخول إلى القناة الصوتية.');
            }

        } else if (sub === 'leave') {
            const connection = getVoiceConnection(message.guild.id);
            if (!connection) return message.reply('❌ البوت غير موجود في أي قناة صوتية.');
            connection.destroy();
            message.reply('✅ تم الخروج من القناة الصوتية.');

        } else {
            message.reply('❌ استخدم: `!voice join` أو `!voice leave`');
        }
    }
};
