const { EmbedBuilder } = require('discord.js');
const config = require('../config');

module.exports = {
    name: 'ban',
    description: 'حظر عضو | !ban @عضو [سبب]',
    async execute(message, args, client) {
        if (!message.member.permissions.has('BanMembers'))
            return message.reply('❌ ليس لديك صلاحية الحظر.');

        const target = message.mentions.members.first();
        if (!target) return message.reply('❌ اذكر العضو: `!ban @عضو [سبب]`');
        if (!target.bannable) return message.reply('❌ لا يمكن حظر هذا العضو.');
        if (target.id === message.author.id) return message.reply('❌ لا يمكنك حظر نفسك.');

        const reason = args.slice(1).join(' ') || 'لم يُحدد سبب';

        try {
            await target.send(`🔨 تم حظرك من **${message.guild.name}**\n📝 السبب: ${reason}`).catch(() => {});
            await target.ban({ reason });

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('🔨 تم الحظر')
                .addFields(
                    { name: '👤 العضو', value: `${target.user.tag}`, inline: true },
                    { name: '🛡️ بواسطة', value: `${message.author.tag}`, inline: true },
                    { name: '📝 السبب', value: reason }
                )
                .setTimestamp();

            await message.channel.send({ embeds: [embed] });

            const logsChannel = message.guild.channels.cache.get(process.env.LOGS_CHANNEL_ID);
            if (logsChannel) await logsChannel.send({ embeds: [embed] });
        } catch (err) {
            message.reply(`❌ فشل الحظر: ${err.message}`);
        }
    }
};
