const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../config');

const DB_PATH = path.join(__dirname, '../data/giveaways.json');

function loadGiveaways() {
    if (!fs.existsSync(DB_PATH)) return {};
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}
function saveGiveaways(data) {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}
function parseDuration(str) {
    const units = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
    const match = str.match(/^(\d+)([smhd])$/);
    if (!match) return null;
    return parseInt(match[1]) * units[match[2]];
}

module.exports = {
    name: 'giveaway',
    aliases: ['gw'],
    description: 'إنشاء مسابقة | !giveaway [مدة] [فائزون] [جائزة]\nمثال: !giveaway 1h 2 نيترو',
    async execute(message, args, client) {
        if (!message.member.permissions.has('ManageGuild'))
            return message.reply('❌ ليس لديك صلاحية إنشاء مسابقة.');

        if (args.length < 3)
            return message.reply('❌ الصيغة: `!giveaway [مدة] [فائزون] [جائزة]`\nمثال: `!giveaway 1h 2 نيترو`');

        const durationStr = args[0];
        const winners = parseInt(args[1]);
        const prize = args.slice(2).join(' ');
        const duration = parseDuration(durationStr);

        if (!duration) return message.reply('❌ صيغة المدة خاطئة. استخدم: `30m` أو `1h` أو `2d`');
        if (isNaN(winners) || winners < 1) return message.reply('❌ عدد الفائزين يجب أن يكون رقماً موجباً.');

        const endTime = Date.now() + duration;

        const embed = new EmbedBuilder()
            .setColor(config.BOT_COLOR)
            .setTitle('🎁 مسابقة جديدة!')
            .setDescription(`**الجائزة:** ${prize}\n\nاضغط على الزر للمشاركة!`)
            .addFields(
                { name: '⏰ تنتهي', value: `<t:${Math.floor(endTime / 1000)}:R>`, inline: true },
                { name: '🏆 الفائزون', value: `${winners}`, inline: true },
                { name: '🎉 المشاركون', value: '0', inline: true }
            )
            .setFooter({ text: `بواسطة ${message.author.tag}` })
            .setTimestamp(endTime);

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('giveaway_join').setLabel('🎉 مشاركة').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId('giveaway_list').setLabel('👥 المشاركون').setStyle(ButtonStyle.Secondary)
        );

        const msg = await message.channel.send({ embeds: [embed], components: [row] });

        const giveaways = loadGiveaways();
        giveaways[msg.id] = {
            messageId: msg.id,
            channelId: message.channel.id,
            guildId: message.guild.id,
            prize, winners, endTime,
            participants: [],
            ended: false,
            hostId: message.author.id,
        };
        saveGiveaways(giveaways);
        message.delete().catch(() => {});
    }
};
