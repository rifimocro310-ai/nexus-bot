const { EmbedBuilder } = require('discord.js');
const config = require('../config');

const cooldowns = new Map();

module.exports = {
    name: 'broadcast',
    description: 'رسالة جماعية لجميع الأعضاء | !broadcast [رسالة]',
    async execute(message, args, client) {
        const allowedRoles = config.ROLES.BROADCAST_ALLOWED;
        const hasPermission = message.member.permissions.has('Administrator') ||
            allowedRoles.some(roleId => message.member.roles.cache.has(roleId));

        if (!hasPermission)
            return message.reply('❌ ليس لديك صلاحية استخدام هذا الأمر.');

        const cooldownMs = config.BROADCAST.COOLDOWN_HOURS * 3600000;
        const lastUsed = cooldowns.get(message.guild.id);
        if (lastUsed && Date.now() - lastUsed < cooldownMs) {
            const remaining = Math.ceil((cooldownMs - (Date.now() - lastUsed)) / 60000);
            return message.reply(`⏳ انتظر ${remaining} دقيقة قبل استخدام هذا الأمر مجدداً.`);
        }

        const text = args.join(' ');
        if (!text) return message.reply('❌ اكتب الرسالة: `!broadcast [رسالة]`');

        cooldowns.set(message.guild.id, Date.now());
        const statusMsg = await message.channel.send('📤 جاري إرسال الرسالة لجميع الأعضاء...');

        const members = await message.guild.members.fetch();
        let sent = 0, failed = 0;

        const embed = new EmbedBuilder()
            .setColor(config.BOT_COLOR)
            .setTitle(`📢 رسالة من إدارة ${message.guild.name}`)
            .setDescription(text)
            .setThumbnail(message.guild.iconURL())
            .setFooter({ text: `أُرسلت بواسطة ${message.author.tag}` })
            .setTimestamp();

        for (const [, member] of members) {
            if (member.user.bot) continue;
            try {
                await member.send({ embeds: [embed] });
                sent++;
                await new Promise(r => setTimeout(r, 500));
            } catch { failed++; }
        }

        await statusMsg.edit(`✅ تم الإرسال!\n📨 نجح: **${sent}**\n❌ فشل (DM مغلق): **${failed}**`);
    }
};
