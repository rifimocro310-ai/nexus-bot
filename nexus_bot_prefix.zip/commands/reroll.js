const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '../data/giveaways.json');

function loadGiveaways() {
    if (!fs.existsSync(DB_PATH)) return {};
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}

module.exports = {
    name: 'reroll',
    description: 'إعادة السحب | !reroll [ID رسالة المسابقة]',
    async execute(message, args, client) {
        if (!message.member.permissions.has('ManageGuild'))
            return message.reply('❌ ليس لديك صلاحية.');

        const msgId = args[0];
        if (!msgId) return message.reply('❌ اذكر ID رسالة المسابقة: `!reroll [ID]`');

        const giveaways = loadGiveaways();
        const gw = giveaways[msgId];

        if (!gw) return message.reply('❌ لم يتم العثور على مسابقة بهذا الـ ID.');
        if (!gw.ended) return message.reply('❌ المسابقة لم تنته بعد.');
        if (!gw.participants.length) return message.reply('❌ لا يوجد مشاركون.');

        const shuffled = [...gw.participants].sort(() => Math.random() - 0.5);
        const newWinners = shuffled.slice(0, gw.winners);
        const mentions = newWinners.map(id => `<@${id}>`).join(', ');

        message.channel.send(`🎉 **إعادة السحب!** الفائزون الجدد: ${mentions}\nتهانينا على الجائزة: **${gw.prize}**`);
    }
};
