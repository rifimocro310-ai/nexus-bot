module.exports = {
    // ======== إعدادات عامة ========
    PREFIX: '!',
    BOT_NAME: 'NexusBot',
    BOT_COLOR: '#FFD700',

    // ======== قنوات السيرفر ========
    CHANNELS: {
        WELCOME: process.env.WELCOME_CHANNEL_ID || '',
        LOGS: process.env.LOGS_CHANNEL_ID || '',
        GIVEAWAY: process.env.GIVEAWAY_CHANNEL_ID || '',
        LEVEL_UP: process.env.LEVELUP_CHANNEL_ID || '',
    },

    // ======== الرولات ========
    ROLES: {
        ADMIN: process.env.ADMIN_ROLE_ID || '',
        MOD: process.env.MOD_ROLE_ID || '',
        MUTED: process.env.MUTED_ROLE_ID || '',
        // رولات مسموح لها باستخدام /broadcast
        BROADCAST_ALLOWED: process.env.BROADCAST_ROLE_IDS
            ? process.env.BROADCAST_ROLE_IDS.split(',').map(r => r.trim())
            : [
                '1483512468100612341',
                '1483512480365023365',
                '1483512482818560082',
                '1483512485956026518',
                '1483512484751998986',
              ],
    },

    // ======== نظام XP ========
    XP: {
        MIN_PER_MESSAGE: 5,
        MAX_PER_MESSAGE: 15,
        COOLDOWN_SECONDS: 60,
        EXCLUDED_CHANNELS: [],
    },

    // ======== الحماية ========
    PROTECTION: {
        ANTI_SPAM: {
            ENABLED: true,
            MAX_MESSAGES: 5,
            TIME_WINDOW_MS: 5000,
            PUNISHMENT: 'timeout',
        },
        ANTI_LINK: {
            ENABLED: true,
            WHITELIST_ROLES: [],
            WHITELIST_DOMAINS: ['discord.gg'],
        },
        ANTI_BOT: {
            ENABLED: true,
        },
    },

    // ======== رسالة الترحيب ========
    WELCOME: {
        MESSAGE: '🎉 مرحباً بك {user} في سيرفر **{server}**!\nأنت العضو رقم **{count}**.',
        DM_MESSAGE: '',
    },

    // ======== Broadcast ========
    BROADCAST: {
        COOLDOWN_HOURS: 1,
    },
};
