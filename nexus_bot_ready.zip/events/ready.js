module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        console.log(`✅ البوت جاهز: ${client.user.tag}`);
        console.log(`📊 يخدم ${client.guilds.cache.size} سيرفر`);
        client.user.setActivity('🎫 نظام متكامل', { type: 3 });
    }
};
