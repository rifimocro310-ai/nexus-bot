const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'guildMemberRemove',
    async execute(member, client) {
        const logsChannel = member.guild.channels.cache.get(process.env.LOGS_CHANNEL_ID);
        if (!logsChannel) return;

        const embed = new EmbedBuilder()
            .setColor('#FF6B6B')
            .setTitle('📤 عضو غادر السيرفر')
            .setDescription(`${member.user.tag} | <@${member.id}>`)
            .addFields(
                { name: '🆔 الايدي', value: member.id, inline: true },
                { name: '📅 انضم منذ', value: member.joinedAt ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>` : 'غير معروف', inline: true }
            )
            .setThumbnail(member.user.displayAvatarURL())
            .setTimestamp();

        await logsChannel.send({ embeds: [embed] }).catch(() => {});
    }
};
