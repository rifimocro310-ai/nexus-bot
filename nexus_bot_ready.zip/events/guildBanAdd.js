const { EmbedBuilder, AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'guildBanAdd',
    async execute(ban, client) {
        const logsChannel = ban.guild.channels.cache.get(process.env.LOGS_CHANNEL_ID);
        if (!logsChannel) return;

        await new Promise(r => setTimeout(r, 1000));
        const auditLogs = await ban.guild.fetchAuditLogs({ type: AuditLogEvent.MemberBan, limit: 1 }).catch(() => null);
        const entry = auditLogs?.entries.first();

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('🔨 تم حظر عضو')
            .setDescription(`${ban.user.tag} | <@${ban.user.id}>`)
            .addFields(
                { name: '📝 السبب', value: entry?.reason || 'غير محدد', inline: true },
                { name: '🛡️ بواسطة', value: entry?.executor?.tag || 'غير معروف', inline: true }
            )
            .setThumbnail(ban.user.displayAvatarURL())
            .setTimestamp();

        await logsChannel.send({ embeds: [embed] }).catch(() => {});
    }
};
