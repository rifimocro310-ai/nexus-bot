const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../config');

const XP_PATH = path.join(__dirname, '../data/xp.json');
const spamTracker = new Map();
const xpCooldowns = new Map();

function loadXP() {
    if (!fs.existsSync(XP_PATH)) return {};
    return JSON.parse(fs.readFileSync(XP_PATH, 'utf8'));
}
function saveXP(data) {
    fs.writeFileSync(XP_PATH, JSON.stringify(data, null, 2));
}
function xpForLevel(level) {
    return 100 * level * level;
}

const LINK_REGEX = /(https?:\/\/|www\.|discord\.gg\/)[^\s]+/gi;

module.exports = {
    name: 'messageCreate',
    async execute(message, client) {
        if (!message.guild || message.author.bot) return;

        const protection = config.PROTECTION;

        // ======== Anti-Link ========
        if (protection.ANTI_LINK.ENABLED) {
            const hasLink = LINK_REGEX.test(message.content);
            LINK_REGEX.lastIndex = 0;

            if (hasLink) {
                const isExempt = protection.ANTI_LINK.WHITELIST_ROLES.some(r => message.member.roles.cache.has(r))
                    || message.member.permissions.has('ManageMessages');

                const isWhitelisted = protection.ANTI_LINK.WHITELIST_DOMAINS.some(d => message.content.includes(d));

                if (!isExempt && !isWhitelisted) {
                    await message.delete().catch(() => {});
                    const warn = await message.channel.send(`⚠️ <@${message.author.id}> ممنوع إرسال الروابط!`);
                    setTimeout(() => warn.delete().catch(() => {}), 5000);
                    return;
                }
            }
        }

        // ======== Anti-Spam ========
        if (protection.ANTI_SPAM.ENABLED && !message.member.permissions.has('ManageMessages')) {
            const key = `${message.guild.id}_${message.author.id}`;
            const now = Date.now();
            const userData = spamTracker.get(key) || { messages: [], warned: false };

            userData.messages = userData.messages.filter(t => now - t < protection.ANTI_SPAM.TIME_WINDOW_MS);
            userData.messages.push(now);
            spamTracker.set(key, userData);

            if (userData.messages.length >= protection.ANTI_SPAM.MAX_MESSAGES) {
                spamTracker.delete(key);
                await message.delete().catch(() => {});

                if (protection.ANTI_SPAM.PUNISHMENT === 'timeout' && message.member.moderatable) {
                    await message.member.timeout(60000, 'Anti-Spam').catch(() => {});
                    await message.channel.send(`🚫 <@${message.author.id}> تم كتمك لمدة دقيقة بسبب الإرسال المتكرر!`)
                        .then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
                } else if (protection.ANTI_SPAM.PUNISHMENT === 'kick' && message.member.kickable) {
                    await message.member.kick('Anti-Spam').catch(() => {});
                }
                return;
            }
        }

        // ======== نظام XP ========
        const xpConfig = config.XP;
        if (xpConfig.EXCLUDED_CHANNELS.includes(message.channel.id)) return;

        const cooldownKey = `${message.guild.id}_${message.author.id}`;
        const lastXP = xpCooldowns.get(cooldownKey) || 0;
        if (Date.now() - lastXP < xpConfig.COOLDOWN_SECONDS * 1000) return;
        xpCooldowns.set(cooldownKey, Date.now());

        const db = loadXP();
        const key = `${message.guild.id}_${message.author.id}`;
        if (!db[key]) db[key] = { xp: 0, level: 0 };

        const earned = Math.floor(Math.random() * (xpConfig.MAX_PER_MESSAGE - xpConfig.MIN_PER_MESSAGE + 1)) + xpConfig.MIN_PER_MESSAGE;
        db[key].xp += earned;

        const required = xpForLevel(db[key].level + 1);
        if (db[key].xp >= required) {
            db[key].xp -= required;
            db[key].level++;

            const levelUpChannel = message.guild.channels.cache.get(process.env.LEVELUP_CHANNEL_ID) || message.channel;
            const embed = new EmbedBuilder()
                .setColor(config.BOT_COLOR)
                .setTitle('🎉 ترقية مستوى!')
                .setDescription(`تهانينا <@${message.author.id}>! وصلت للمستوى **${db[key].level}** 🏅`)
                .setThumbnail(message.author.displayAvatarURL())
                .setTimestamp();
            await levelUpChannel.send({ embeds: [embed] }).catch(() => {});
        }

        saveXP(db);
    }
};
