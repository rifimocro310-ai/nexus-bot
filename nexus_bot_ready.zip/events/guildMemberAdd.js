const { EmbedBuilder } = require('discord.js');
const config = require('../config');

module.exports = {
    name: 'guildMemberAdd',
    async execute(member, client) {
        // Anti-Bot
        if (member.user.bot && config.PROTECTION.ANTI_BOT.ENABLED) {
            try {
                await member.kick('Anti-Bot: بوت غير مصرح به');
                const logsChannel = member.guild.channels.cache.get(process.env.LOGS_CHANNEL_ID);
                if (logsChannel) {
                    const embed = new EmbedBuilder()
                        .setColor('#FF0000')
                        .setTitle('🤖 Anti-Bot - تم طرد بوت')
                        .setDescription(`تم طرد البوت **${member.user.tag}** تلقائياً.`)
                        .setTimestamp();
                    await logsChannel.send({ embeds: [embed] });
                }
            } catch {}
            return;
        }

        // رسالة الترحيب
        const welcomeChannelId = process.env.WELCOME_CHANNEL_ID;
        if (!welcomeChannelId) return;

        const channel = member.guild.channels.cache.get(welcomeChannelId);
        if (!channel) return;

        const message = config.WELCOME.MESSAGE
            .replace('{user}', `<@${member.id}>`)
            .replace('{server}', member.guild.name)
            .replace('{count}', member.guild.memberCount.toString());

        const embed = new EmbedBuilder()
            .setColor(config.BOT_COLOR)
            .setTitle('👋 عضو جديد!')
            .setDescription(message)
            .setThumbnail(member.user.displayAvatarURL({ size: 256 }))
            .setFooter({ text: member.guild.name, iconURL: member.guild.iconURL() })
            .setTimestamp();

        await channel.send({ embeds: [embed] }).catch(console.error);

        // Log دخول العضو
        const logsChannel = member.guild.channels.cache.get(process.env.LOGS_CHANNEL_ID);
        if (logsChannel) {
            const logEmbed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('📥 عضو جديد انضم')
                .setDescription(`${member.user.tag} | <@${member.id}>`)
                .addFields(
                    { name: '🆔 الايدي', value: member.id, inline: true },
                    { name: '📅 حساب منذ', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true }
                )
                .setThumbnail(member.user.displayAvatarURL())
                .setTimestamp();
            await logsChannel.send({ embeds: [logEmbed] }).catch(() => {});
        }
    }
};
