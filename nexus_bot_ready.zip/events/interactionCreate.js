const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '../data/giveaways.json');

function loadGiveaways() {
    if (!fs.existsSync(DB_PATH)) return {};
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}
function saveGiveaways(data) {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {

        // معالجة Slash Commands
        if (interaction.isChatInputCommand()) {
            const command = client.commands.get(interaction.commandName);
            if (!command) return;

            try {
                await command.execute(interaction, client);
            } catch (err) {
                console.error(`❌ خطأ في الأمر /${interaction.commandName}:`, err);
                const msg = { content: '❌ حدث خطأ أثناء تنفيذ الأمر.', ephemeral: true };
                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp(msg).catch(() => {});
                } else {
                    await interaction.reply(msg).catch(() => {});
                }
            }
            return;
        }

        // معالجة أزرار Giveaway
        if (interaction.isButton()) {
            if (interaction.customId === 'giveaway_join') {
                const giveaways = loadGiveaways();
                const msg = interaction.message;
                const gw = giveaways[msg.id];

                if (!gw) return interaction.reply({ content: '❌ لم يتم العثور على هذه المسابقة.', ephemeral: true });
                if (gw.ended) return interaction.reply({ content: '⏰ انتهت هذه المسابقة بالفعل.', ephemeral: true });

                if (gw.participants.includes(interaction.user.id)) {
                    // إلغاء المشاركة
                    gw.participants = gw.participants.filter(id => id !== interaction.user.id);
                    saveGiveaways(giveaways);
                    await interaction.reply({ content: '❎ تم إلغاء مشاركتك في المسابقة.', ephemeral: true });
                } else {
                    // المشاركة
                    gw.participants.push(interaction.user.id);
                    saveGiveaways(giveaways);
                    await interaction.reply({ content: '🎉 تم تسجيل مشاركتك في المسابقة!', ephemeral: true });
                }

                // تحديث عداد المشاركين
                const updatedEmbed = EmbedBuilder.from(msg.embeds[0]);
                const fields = updatedEmbed.data.fields;
                const idx = fields.findIndex(f => f.name === '🎉 المشاركون');
                if (idx !== -1) fields[idx].value = `${giveaways[msg.id].participants.length}`;
                await msg.edit({ embeds: [updatedEmbed] }).catch(() => {});

            } else if (interaction.customId === 'giveaway_list') {
                const giveaways = loadGiveaways();
                const gw = giveaways[interaction.message.id];
                if (!gw || !gw.participants.length) {
                    return interaction.reply({ content: '📋 لا يوجد مشاركون حتى الآن.', ephemeral: true });
                }
                const list = gw.participants.slice(0, 20).map((id, i) => `${i + 1}. <@${id}>`).join('\n');
                await interaction.reply({ content: `👥 **المشاركون (${gw.participants.length}):**\n${list}`, ephemeral: true });
            }
        }
    }
};
