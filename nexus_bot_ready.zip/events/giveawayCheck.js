const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '../data/giveaways.json');

function loadGiveaways() {
    if (!fs.existsSync(DB_PATH)) return {};
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}
function saveGiveaways(data) {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

module.exports = async function giveawayCheck(client) {
    const giveaways = loadGiveaways();
    const now = Date.now();

    for (const [msgId, gw] of Object.entries(giveaways)) {
        if (gw.ended || now < gw.endTime) continue;

        gw.ended = true;
        saveGiveaways(giveaways);

        try {
            const channel = await client.channels.fetch(gw.channelId).catch(() => null);
            if (!channel) continue;
            const message = await channel.messages.fetch(msgId).catch(() => null);
            if (!message) continue;

            const disabledRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('giveaway_ended').setLabel('🔒 انتهت المسابقة').setStyle(ButtonStyle.Secondary).setDisabled(true)
            );

            if (!gw.participants.length) {
                const noWinnersEmbed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('🎁 انتهت المسابقة')
                    .setDescription(`**الجائزة:** ${gw.prize}\n\n❌ لم يشارك أحد.`)
                    .setTimestamp();
                await message.edit({ embeds: [noWinnersEmbed], components: [disabledRow] });
                await channel.send(`❌ انتهت مسابقة **${gw.prize}** دون فائزين!`);
                continue;
            }

            const shuffled = [...gw.participants].sort(() => Math.random() - 0.5);
            const winnerIds = shuffled.slice(0, gw.winners);
            const mentions = winnerIds.map(id => `<@${id}>`).join(', ');

            const endedEmbed = new EmbedBuilder()
                .setColor('#FFD700')
                .setTitle('🎁 انتهت المسابقة!')
                .setDescription(`**الجائزة:** ${gw.prize}\n\n🏆 **الفائزون:** ${mentions}`)
                .addFields(
                    { name: '🎉 المشاركون', value: `${gw.participants.length}`, inline: true },
                    { name: '🏆 الفائزون', value: `${gw.winners}`, inline: true }
                )
                .setTimestamp();

            await message.edit({ embeds: [endedEmbed], components: [disabledRow] });
            await channel.send(`🎉 تهانينا ${mentions}! فزتم بـ **${gw.prize}**!\nلإعادة السحب: \`/reroll\``);

        } catch (err) {
            console.error('خطأ في Giveaway Check:', err.message);
        }
    }
};
