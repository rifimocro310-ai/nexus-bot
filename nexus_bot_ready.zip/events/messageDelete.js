const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'messageDelete',
    async execute(message, client) {
        if (!message.guild || message.author?.bot) return;
        const logsChannel = message.guild.channels.cache.get(process.env.LOGS_CHANNEL_ID);
        if (!logsChannel) return;

        const embed = new EmbedBuilder()
            .setColor('#FFA500')
            .setTitle('🗑️ رسالة محذوفة')
            .setDescription(`في <#${message.channel.id}> بواسطة ${message.author ? `<@${message.author.id}>` : 'غير معروف'}`)
            .addFields(
                { name: '💬 المحتوى', value: message.content?.slice(0, 1000) || '*(لا يوجد نص)*' }
            )
            .setTimestamp();

        await logsChannel.send({ embeds: [embed] }).catch(() => {});
    }
};
