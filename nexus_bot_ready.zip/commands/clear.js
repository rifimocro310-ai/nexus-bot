const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('clear')
        .setDescription('حذف عدد محدد من الرسائل في القناة الحالية')
        .addIntegerOption(o => o.setName('عدد').setDescription('عدد الرسائل المراد حذفها (1-100)').setRequired(true).setMinValue(1).setMaxValue(100))
        .addUserOption(o => o.setName('عضو').setDescription('حذف رسائل عضو محدد فقط').setRequired(false)),

    async execute(interaction) {
        if (!interaction.member.permissions.has('ManageMessages')) {
            return interaction.reply({ content: '❌ ليس لديك صلاحية حذف الرسائل.', ephemeral: true });
        }

        const amount = interaction.options.getInteger('عدد');
        const targetUser = interaction.options.getUser('عضو');

        await interaction.deferReply({ ephemeral: true });

        try {
            let messages = await interaction.channel.messages.fetch({ limit: amount + 1 });

            if (targetUser) {
                messages = messages.filter(m => m.author.id === targetUser.id);
            }

            // نفلتر الرسائل الأقدم من 14 يوم
            const deletable = messages.filter(m => Date.now() - m.createdTimestamp < 1209600000);
            await interaction.channel.bulkDelete(deletable, true);

            await interaction.editReply({ content: `✅ تم حذف **${deletable.size}** رسالة.` });
        } catch (err) {
            await interaction.editReply({ content: `❌ فشل الحذف: ${err.message}` });
        }
    }
};
