const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../config');

const DB_PATH = path.join(__dirname, '../data/xp.json');

function loadXP() {
    if (!fs.existsSync(DB_PATH)) return {};
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('leaderboard')
        .setDescription('عرض قائمة أفضل الأعضاء حسب المستوى داخل السيرفر'),

    async execute(interaction) {
        await interaction.deferReply();
        const db = loadXP();
        const guildId = interaction.guild.id;

        const sorted = Object.entries(db)
            .filter(([k]) => k.startsWith(guildId))
            .sort(([, a], [, b]) => b.level !== a.level ? b.level - a.level : b.xp - a.xp)
            .slice(0, 10);

        if (!sorted.length) {
            return interaction.editReply({ content: '❌ لا يوجد بيانات بعد.' });
        }

        const medals = ['🥇', '🥈', '🥉'];
        let description = '';

        for (let i = 0; i < sorted.length; i++) {
            const [key, data] = sorted[i];
            const userId = key.replace(`${guildId}_`, '');
            const medal = medals[i] || `**${i + 1}.**`;
            description += `${medal} <@${userId}> — المستوى **${data.level}** | XP: **${data.xp}**\n`;
        }

        const embed = new EmbedBuilder()
            .setColor(config.BOT_COLOR)
            .setTitle(`🏆 أفضل الأعضاء في ${interaction.guild.name}`)
            .setDescription(description)
            .setThumbnail(interaction.guild.iconURL())
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    }
};
