const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../config');

const DB_PATH = path.join(__dirname, '../data/xp.json');

function loadXP() {
    if (!fs.existsSync(DB_PATH)) return {};
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}

function xpForLevel(level) {
    return 100 * level * level;
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('rank')
        .setDescription('عرض مستوى المستخدم الحالي وعدد نقاط الخبرة (XP)')
        .addUserOption(o => o.setName('عضو').setDescription('عرض مستوى عضو آخر').setRequired(false)),

    async execute(interaction) {
        const target = interaction.options.getMember('عضو') || interaction.member;
        const db = loadXP();
        const userId = target.id;
        const guildId = interaction.guild.id;
        const key = `${guildId}_${userId}`;

        const userData = db[key] || { xp: 0, level: 0 };
        const currentXP = userData.xp;
        const currentLevel = userData.level;
        const requiredXP = xpForLevel(currentLevel + 1);
        const progress = Math.floor((currentXP / requiredXP) * 20);
        const bar = '█'.repeat(progress) + '░'.repeat(20 - progress);

        // حساب الترتيب
        const allUsers = Object.entries(db)
            .filter(([k]) => k.startsWith(guildId))
            .sort(([, a], [, b]) => (b.xp + b.level * 1000) - (a.xp + a.level * 1000));
        const rank = allUsers.findIndex(([k]) => k === key) + 1;

        const embed = new EmbedBuilder()
            .setColor(config.BOT_COLOR)
            .setTitle(`⭐ مستوى ${target.user.username}`)
            .setThumbnail(target.user.displayAvatarURL())
            .addFields(
                { name: '🏅 المستوى', value: `${currentLevel}`, inline: true },
                { name: '✨ XP', value: `${currentXP} / ${requiredXP}`, inline: true },
                { name: '🏆 الترتيب', value: rank > 0 ? `#${rank}` : 'غير مصنف', inline: true },
                { name: '📊 التقدم', value: `\`${bar}\` ${Math.floor((currentXP / requiredXP) * 100)}%` }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};
