const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config');

const cooldowns = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('broadcast')
        .setDescription('إرسال رسالة خاصة (DM) إلى جميع أعضاء السيرفر')
        .addStringOption(o => o.setName('رسالة').setDescription('الرسالة التي سيتم إرسالها').setRequired(true)),

    async execute(interaction, client) {
        // التحقق من الرولات المسموح لها باستخدام /broadcast
        const allowedRoles = config.ROLES.BROADCAST_ALLOWED;
        const memberRoles = interaction.member.roles.cache;
        const hasPermission = interaction.member.permissions.has('Administrator') ||
            allowedRoles.some(roleId => memberRoles.has(roleId));

        if (!hasPermission) {
            return interaction.reply({ content: '❌ ليس لديك صلاحية استخدام هذا الأمر.', ephemeral: true });
        }

        const cooldownMs = config.BROADCAST.COOLDOWN_HOURS * 3600000;
        const lastUsed = cooldowns.get(interaction.guild.id);
        if (lastUsed && Date.now() - lastUsed < cooldownMs) {
            const remaining = Math.ceil((cooldownMs - (Date.now() - lastUsed)) / 60000);
            return interaction.reply({ content: `⏳ انتظر ${remaining} دقيقة قبل استخدام هذا الأمر مجدداً.`, ephemeral: true });
        }

        const message = interaction.options.getString('رسالة');
        await interaction.reply({ content: `📤 جاري إرسال الرسالة لجميع الأعضاء...`, ephemeral: true });
        cooldowns.set(interaction.guild.id, Date.now());

        const members = await interaction.guild.members.fetch();
        let sent = 0, failed = 0;

        const embed = new EmbedBuilder()
            .setColor(config.BOT_COLOR)
            .setTitle(`📢 رسالة من إدارة ${interaction.guild.name}`)
            .setDescription(message)
            .setThumbnail(interaction.guild.iconURL())
            .setFooter({ text: `أُرسلت بواسطة ${interaction.user.tag}` })
            .setTimestamp();

        for (const [, member] of members) {
            if (member.user.bot) continue;
            try {
                await member.send({ embeds: [embed] });
                sent++;
                await new Promise(r => setTimeout(r, 500));
            } catch { failed++; }
        }

        await interaction.followUp({ content: `✅ تم الإرسال!\n📨 نجح: **${sent}**\n❌ فشل (DM مغلق): **${failed}**`, ephemeral: true });
    }
};
