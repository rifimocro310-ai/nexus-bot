const { SlashCommandBuilder } = require('discord.js');
const { joinVoiceChannel, VoiceConnectionStatus, entersState } = require('@discordjs/voice');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('voice')
        .setDescription('التحكم في البقاء في القنوات الصوتية')
        .addSubcommand(sub =>
            sub.setName('join').setDescription('الدخول إلى القناة الصوتية والبقاء فيها'))
        .addSubcommand(sub =>
            sub.setName('leave').setDescription('الخروج من القناة الصوتية')),

    async execute(interaction, client) {
        const sub = interaction.options.getSubcommand();

        if (sub === 'join') {
            const voiceChannel = interaction.member.voice.channel;
            if (!voiceChannel) {
                return interaction.reply({ content: '❌ يجب أن تكون في قناة صوتية أولاً.', ephemeral: true });
            }

            try {
                const connection = joinVoiceChannel({
                    channelId: voiceChannel.id,
                    guildId: interaction.guild.id,
                    adapterCreator: interaction.guild.voiceAdapterCreator,
                    selfDeaf: true,
                    selfMute: true,
                });

                await entersState(connection, VoiceConnectionStatus.Ready, 30_000);
                await interaction.reply({ content: `✅ تم الدخول إلى **${voiceChannel.name}** وسأبقى فيها.` });
            } catch (err) {
                await interaction.reply({ content: '❌ تعذر الدخول إلى القناة الصوتية.', ephemeral: true });
            }

        } else if (sub === 'leave') {
            const { getVoiceConnection } = require('@discordjs/voice');
            const connection = getVoiceConnection(interaction.guild.id);
            if (!connection) {
                return interaction.reply({ content: '❌ البوت غير موجود في أي قناة صوتية.', ephemeral: true });
            }
            connection.destroy();
            await interaction.reply({ content: '✅ تم الخروج من القناة الصوتية.' });
        }
    }
};
