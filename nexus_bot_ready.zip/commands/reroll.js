const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '../data/giveaways.json');

function loadGiveaways() {
    if (!fs.existsSync(DB_PATH)) return {};
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('reroll')
        .setDescription('إعادة سحب الفائزين في مسابقة منتهية')
        .addStringOption(o => o.setName('message_id').setDescription('ID رسالة المسابقة').setRequired(true)),

    async execute(interaction) {
        if (!interaction.member.permissions.has('ManageGuild')) {
            return interaction.reply({ content: '❌ ليس لديك صلاحية.', ephemeral: true });
        }

        const msgId = interaction.options.getString('message_id');
        const giveaways = loadGiveaways();
        const gw = giveaways[msgId];

        if (!gw) return interaction.reply({ content: '❌ لم يتم العثور على مسابقة بهذا الـ ID.', ephemeral: true });
        if (!gw.ended) return interaction.reply({ content: '❌ المسابقة لم تنته بعد.', ephemeral: true });
        if (!gw.participants.length) return interaction.reply({ content: '❌ لا يوجد مشاركون.', ephemeral: true });

        const shuffled = [...gw.participants].sort(() => Math.random() - 0.5);
        const newWinners = shuffled.slice(0, gw.winners);
        const mentions = newWinners.map(id => `<@${id}>`).join(', ');

        await interaction.reply({ content: `🎉 **إعادة السحب!** الفائزون الجدد: ${mentions}\nتهانينا على الجائزة: **${gw.prize}**` });
    }
};
