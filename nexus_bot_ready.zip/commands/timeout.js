const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

function parseDuration(str) {
    const units = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
    const match = str.match(/^(\d+)([smhd])$/);
    if (!match) return null;
    return parseInt(match[1]) * units[match[2]];
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('timeout')
        .setDescription('كتم عضو مؤقتاً لمدة محددة مع تحديد السبب')
        .addUserOption(o => o.setName('عضو').setDescription('العضو المراد كتمه').setRequired(true))
        .addStringOption(o => o.setName('مدة').setDescription('مدة الكتم (مثال: 10m، 1h، 2d)').setRequired(true))
        .addStringOption(o => o.setName('سبب').setDescription('سبب الكتم').setRequired(false)),

    async execute(interaction) {
        if (!interaction.member.permissions.has('ModerateMembers')) {
            return interaction.reply({ content: '❌ ليس لديك صلاحية الكتم.', ephemeral: true });
        }

        const target = interaction.options.getMember('عضو');
        const durationStr = interaction.options.getString('مدة');
        const reason = interaction.options.getString('سبب') || 'لم يُحدد سبب';
        const duration = parseDuration(durationStr);

        if (!duration) return interaction.reply({ content: '❌ صيغة المدة غير صحيحة. مثال: `10m` أو `1h`', ephemeral: true });
        if (duration > 2419200000) return interaction.reply({ content: '❌ الحد الأقصى للكتم 28 يوم.', ephemeral: true });
        if (!target) return interaction.reply({ content: '❌ العضو غير موجود.', ephemeral: true });
        if (!target.moderatable) return interaction.reply({ content: '❌ لا يمكن كتم هذا العضو.', ephemeral: true });

        try {
            await target.timeout(duration, reason);
            await target.send(`🔇 تم كتمك في **${interaction.guild.name}** لمدة **${durationStr}**\n📝 السبب: ${reason}`).catch(() => {});

            const embed = new EmbedBuilder()
                .setColor('#FFFF00')
                .setTitle('🔇 تم الكتم')
                .addFields(
                    { name: '👤 العضو', value: `${target.user.tag}`, inline: true },
                    { name: '⏰ المدة', value: durationStr, inline: true },
                    { name: '🛡️ بواسطة', value: `${interaction.user.tag}`, inline: true },
                    { name: '📝 السبب', value: reason }
                )
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
            const logsChannel = interaction.guild.channels.cache.get(process.env.LOGS_CHANNEL_ID);
            if (logsChannel) await logsChannel.send({ embeds: [embed] });

        } catch (err) {
            await interaction.reply({ content: `❌ فشل الكتم: ${err.message}`, ephemeral: true });
        }
    }
};
