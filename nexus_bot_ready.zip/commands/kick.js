const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('kick')
        .setDescription('طرد عضو من السيرفر مع إمكانية تحديد السبب')
        .addUserOption(o => o.setName('عضو').setDescription('العضو المراد طرده').setRequired(true))
        .addStringOption(o => o.setName('سبب').setDescription('سبب الطرد').setRequired(false)),

    async execute(interaction) {
        if (!interaction.member.permissions.has('KickMembers')) {
            return interaction.reply({ content: '❌ ليس لديك صلاحية الطرد.', ephemeral: true });
        }

        const target = interaction.options.getMember('عضو');
        const reason = interaction.options.getString('سبب') || 'لم يُحدد سبب';

        if (!target) return interaction.reply({ content: '❌ العضو غير موجود.', ephemeral: true });
        if (!target.kickable) return interaction.reply({ content: '❌ لا يمكن طرد هذا العضو.', ephemeral: true });
        if (target.id === interaction.user.id) return interaction.reply({ content: '❌ لا يمكنك طرد نفسك.', ephemeral: true });

        try {
            await target.send(`👢 تم طردك من **${interaction.guild.name}**\n📝 السبب: ${reason}`).catch(() => {});
            await target.kick(reason);

            const embed = new EmbedBuilder()
                .setColor('#FFA500')
                .setTitle('👢 تم الطرد')
                .addFields(
                    { name: '👤 العضو', value: `${target.user.tag}`, inline: true },
                    { name: '🛡️ بواسطة', value: `${interaction.user.tag}`, inline: true },
                    { name: '📝 السبب', value: reason }
                )
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
            const logsChannel = interaction.guild.channels.cache.get(process.env.LOGS_CHANNEL_ID);
            if (logsChannel) await logsChannel.send({ embeds: [embed] });

        } catch (err) {
            await interaction.reply({ content: `❌ فشل الطرد: ${err.message}`, ephemeral: true });
        }
    }
};
