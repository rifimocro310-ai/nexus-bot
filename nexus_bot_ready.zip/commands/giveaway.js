const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../config');

const DB_PATH = path.join(__dirname, '../data/giveaways.json');

function loadGiveaways() {
    if (!fs.existsSync(DB_PATH)) return {};
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}

function saveGiveaways(data) {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function parseDuration(str) {
    const units = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
    const match = str.match(/^(\d+)([smhd])$/);
    if (!match) return null;
    return parseInt(match[1]) * units[match[2]];
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('giveaway')
        .setDescription('إنشاء مسابقة (Giveaway) داخل السيرفر مع تحديد الجائزة وعدد الفائزين ومدة المسابقة')
        .addStringOption(o => o.setName('مدة').setDescription('مدة المسابقة (مثال: 1h، 30m، 2d)').setRequired(true))
        .addIntegerOption(o => o.setName('فائزون').setDescription('عدد الفائزين').setRequired(true).setMinValue(1).setMaxValue(20))
        .addStringOption(o => o.setName('جائزة').setDescription('اسم الجائزة').setRequired(true)),

    async execute(interaction, client) {
        if (!interaction.member.permissions.has('ManageGuild')) {
            return interaction.reply({ content: '❌ ليس لديك صلاحية إنشاء مسابقة.', ephemeral: true });
        }

        const durationStr = interaction.options.getString('مدة');
        const winners = interaction.options.getInteger('فائزون');
        const prize = interaction.options.getString('جائزة');
        const duration = parseDuration(durationStr);

        if (!duration) {
            return interaction.reply({ content: '❌ صيغة المدة غير صحيحة. مثال: `1h` أو `30m` أو `2d`', ephemeral: true });
        }

        const endTime = Date.now() + duration;

        const embed = new EmbedBuilder()
            .setColor(config.BOT_COLOR)
            .setTitle('🎁 مسابقة جديدة!')
            .setDescription(`**الجائزة:** ${prize}\n\n اضغط على الزر للمشاركة!`)
            .addFields(
                { name: '⏰ تنتهي', value: `<t:${Math.floor(endTime / 1000)}:R>`, inline: true },
                { name: '🏆 الفائزون', value: `${winners}`, inline: true },
                { name: '🎉 المشاركون', value: '0', inline: true }
            )
            .setFooter({ text: `بواسطة ${interaction.user.tag}` })
            .setTimestamp(endTime);

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('giveaway_join')
                .setLabel('🎉 مشاركة')
                .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId('giveaway_list')
                .setLabel('👥 المشاركون')
                .setStyle(ButtonStyle.Secondary)
        );

        await interaction.reply({ content: '✅ تم إنشاء المسابقة!', ephemeral: true });
        const msg = await interaction.channel.send({ embeds: [embed], components: [row] });

        const giveaways = loadGiveaways();
        giveaways[msg.id] = {
            messageId: msg.id,
            channelId: interaction.channel.id,
            guildId: interaction.guild.id,
            prize,
            winners,
            endTime,
            participants: [],
            ended: false,
            hostId: interaction.user.id,
        };
        saveGiveaways(giveaways);
    }
};
