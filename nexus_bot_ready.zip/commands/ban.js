const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ban')
        .setDescription('حظر عضو من السيرفر مع إمكانية تحديد السبب')
        .addUserOption(o => o.setName('عضو').setDescription('العضو المراد حظره').setRequired(true))
        .addStringOption(o => o.setName('سبب').setDescription('سبب الحظر').setRequired(false))
        .addIntegerOption(o => o.setName('حذف_رسائل').setDescription('حذف رسائل آخر X أيام (0-7)').setMinValue(0).setMaxValue(7)),

    async execute(interaction, client) {
        if (!interaction.member.permissions.has('BanMembers')) {
            return interaction.reply({ content: '❌ ليس لديك صلاحية الحظر.', ephemeral: true });
        }

        const target = interaction.options.getMember('عضو');
        const reason = interaction.options.getString('سبب') || 'لم يُحدد سبب';
        const days = interaction.options.getInteger('حذف_رسائل') || 0;

        if (!target) return interaction.reply({ content: '❌ العضو غير موجود.', ephemeral: true });
        if (!target.bannable) return interaction.reply({ content: '❌ لا يمكن حظر هذا العضو.', ephemeral: true });
        if (target.id === interaction.user.id) return interaction.reply({ content: '❌ لا يمكنك حظر نفسك.', ephemeral: true });

        try {
            await target.send(`🔨 تم حظرك من **${interaction.guild.name}**\n📝 السبب: ${reason}`).catch(() => {});
            await target.ban({ deleteMessageSeconds: days * 86400, reason });

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('🔨 تم الحظر')
                .addFields(
                    { name: '👤 العضو', value: `${target.user.tag}`, inline: true },
                    { name: '🛡️ بواسطة', value: `${interaction.user.tag}`, inline: true },
                    { name: '📝 السبب', value: reason }
                )
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

            // إرسال للوق
            const logsChannel = interaction.guild.channels.cache.get(process.env.LOGS_CHANNEL_ID);
            if (logsChannel) await logsChannel.send({ embeds: [embed] });

        } catch (err) {
            await interaction.reply({ content: `❌ فشل الحظر: ${err.message}`, ephemeral: true });
        }
    }
};
